from logic import *
from truthtable import *
from sentence_transformers import *
import re

'''Read from file'''
def read(filename):
    with open(filename) as f:
        lines = [line.strip().lower().split(";") for line in f]
    flattened_lines = [item for sublist in lines for item in sublist]
    
    try:
        query_index = flattened_lines.index('ask')
    except ValueError:
        query_index = len(flattened_lines)

    tell = [x.replace(" ", "") for x in flattened_lines[:query_index] if x not in ["", "tell", "ask"]]
    query = flattened_lines[query_index + 1].replace(" ", "") if query_index + 1 < len(flattened_lines) else ''

    return tell, query  
    
'''Extract Symbol'''
def extract_symbols(tell):
    symbols = set()
    for sentence in tell:
        symbols.update(re.findall(r'\b[a-zA-Z][a-zA-Z0-9]*\b', sentence))
    return symbols

def extract_symbols_and_sentences(tell):
    symbols = set()
    sentences = []
    for sentence in tell:
        symbols.update(re.findall(r'\b[a-zA-Z][a-zA-Z0-9]*\b', sentence))
        sentences.append(sentence)
    return symbols, sentences

def parse_sentences(symbols, sentences):
    sentence_objects = []
    for sentence in sentences:
        # Replace symbols with Symbol instances
        for symbol in symbols:
            sentence = sentence.replace(symbol, f"Symbol('{symbol}')")

        # Replace logical operators with Python operators
        sentence = sentence.replace('<=>', 'Biconditional').replace('=>', 'Implication').replace('~', 'Negation')
        sentence = re.sub(r'([^a-zA-Z])([a-zA-Z])', r'\1Symbol("\2")', sentence)
        sentence = sentence.replace('&', 'and').replace('||', 'or')

        sentence_objects.append(eval(sentence))
    return Conjunction(*sentence_objects)

# Create knowledge base dynamically from sentences
# def create_knowledge_base(symbols, sentences):
#     # Use eval to dynamically create Symbol instances
#     symbols = {s: eval(f"Symbol('{s}')") for s in symbols}
#     kb = []

#     for sentence in sentences:
#         for symbol, obj in symbols.items():
#             sentence = sentence.replace(symbol, f"{symbol}_obj")
#             sentence = sentence.replace(f"{symbol}_obj", f"symbols['{symbol}']")
#         sentence = sentence.replace('<=>', ', Biconditional(').replace('=>', ', Implication(')
#         sentence = sentence.replace('&', ', Conjunction(').replace('||', ', Disjunction(')
#         sentence = sentence.replace('~', 'Negation(')
#         sentence = sentence + ')' * sentence.count(',')  # Add closing brackets
#         kb.append(eval(sentence))

#     return Conjunction(*kb)

'''Test Function'''
# Read File
#filename = 'test_genericKB.txt' 
filename = 'test_HornKB.txt'
tell, query = read(filename)
print(f'Tell: {tell}')
print(f'Query: {query}')

# Extract symbol
symbols, sentences = extract_symbols_and_sentences(tell)
print(f'Symbols: {symbols}')
print(f'Sentence: {sentences}')


# Create a dictionary to hold Symbol instances
symbol_objects = {}

# Create a Symbol instance for each unique symbol and store it in the dictionary
for symbol in symbols:
    symbol_objects[symbol] = Symbol(symbol)

print(symbol_objects)
print(len(symbol_objects))

knowledge_base = create_knowledge_base(sentences)

print(knowledge_base)

# Create a TruthTable instance
tt = TruthTable(list(symbols), knowledge_base)

# Print the truth table
print(tt)


