from lark import Lark, Transformer, v_args
from logic import *

class SentenceTransformer(Transformer):
    @v_args(inline=True)
    def symbol(self, name):
        return Symbol(name[0])

    def negation(self, args):
        return Negation(args[0])

    def conjunction(self, args):
        return Conjunction(*args)

    def disjunction(self, args):
        return Disjunction(*args)

    def implication(self, args):
        return Implication(*args)

    def biconditional(self, args):
        return Biconditional(*args)

sentence_parser = Lark(r"""
    ?start: sentence
    ?sentence: symbol
        | "(" sentence ")"
        | negation
        | conjunction
        | disjunction
        | implication
        | biconditional
    negation: "~" sentence
    conjunction: sentence "&" sentence
    disjunction: sentence "||" sentence
    implication: sentence "=>" sentence
    biconditional: sentence "<=>" sentence
    symbol: /[a-z0-9]+/
    %import common.WS
    %ignore WS
""", start='start', parser='lalr', transformer=SentenceTransformer())

def parse(sentence):
    return sentence_parser.parse(sentence)

def create_knowledge_base(sentences):
    return Conjunction(*[parse(sentence) for sentence in sentences])