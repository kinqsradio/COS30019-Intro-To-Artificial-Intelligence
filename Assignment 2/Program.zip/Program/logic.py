class Sentence:
    def __init__(self, *args):
        self.args = args

    def evaluate(self, model):
        pass

class Symbol(Sentence):
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return self.name

    def evaluate(self, model):
        return model.get(self.name, False)

class Negation(Sentence):
    def __repr__(self):
        return f'~{self.args[0]}'

    def evaluate(self, model):
        return not self.args[0].evaluate(model)

class Conjunction(Sentence):
    def __repr__(self):
        return f'({self.args[0]} & {self.args[1]})'

    def evaluate(self, model):
        return self.args[0].evaluate(model) and self.args[1].evaluate(model)

class Disjunction(Sentence):
    def __repr__(self):
        return f'({self.args[0]} || {self.args[1]})'

    def evaluate(self, model):
        return self.args[0].evaluate(model) or self.args[1].evaluate(model)

class Implication(Sentence):
    def __repr__(self):
        return f'({self.args[0]} => {self.args[1]})'

    def evaluate(self, model):
        return not self.args[0].evaluate(model) or self.args[1].evaluate(model)

class Biconditional(Sentence):
    def __repr__(self):
        return f'({self.args[0]} <=> {self.args[1]})'

    def evaluate(self, model):
        return self.args[0].evaluate(model) == self.args[1].evaluate(model)
