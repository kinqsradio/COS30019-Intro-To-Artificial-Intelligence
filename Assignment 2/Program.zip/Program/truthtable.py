from itertools import product

class TruthTable:
    
    def __init__(self, symbols, knowledgeBase):
        self.symbols = sorted(symbols)
        self.knowledgeBase = knowledgeBase
        self.table = self.generate_table()

    def generate_table(self):
        # Generate all combinations of truth values
        combinations = list(product([True, False], repeat=len(self.symbols)))

        # For each combination, create a dictionary mapping symbols to truth values
        models = [{symbol: value for symbol, value in zip(self.symbols, combination)} for combination in combinations]

        # Evaluate the knowledgeBase for each model
        evaluations = [self.knowledgeBase.evaluate(model) for model in models]

        return list(zip(models, evaluations))

    def __str__(self):
        table_str = ''

        # Add symbols and knowledgeBase on top
        for symbol in self.symbols:
            table_str += str(symbol) + '\t'
        table_str += str(self.knowledgeBase) + '\n'

        # Add the rows of the table
        for model, evaluation in self.table:
            for symbol in self.symbols:
                table_str += str(model[symbol]) + '\t'
            table_str += str(evaluation) + '\n'

        return table_str


